
class DataJson{
  static List<int> summa = [780,800,350,400,480,600,700,580,750,550];
  static List<String> type = ["Beosound A1","Beoplay H9","Beoplay E8","Beoplay H8i","Authaund F9Y","Beosound A1","Beoplay H9","Beoplay E8","Beoplay H8i","Authaund F9Y"];
  static List<String> image = [
    "https://i.ya-webdesign.com/images/headphone-transparent-white-9.png",
    "https://platincdn.com/3285/pictures/UIDUPBUKID5142020195255_hdj-s7-w-main.png",
    "https://ae01.alicdn.com/kf/H1ed50737c0764491b11e22aeeeb61559X/B-O-Beoplay-E8-Motion-TWS-In-Ear-Bluetooth.jpg_q50.jpg",
    "https://www.pikpng.com/pngl/b/209-2097143_beoplay-h9i-limestone-clipart.png",
    "https://i.ya-webdesign.com/images/headphone-transparent-white-9.png",
    "https://platincdn.com/3285/pictures/UIDUPBUKID5142020195255_hdj-s7-w-main.png",
    "https://ae01.alicdn.com/kf/H1ed50737c0764491b11e22aeeeb61559X/B-O-Beoplay-E8-Motion-TWS-In-Ear-Bluetooth.jpg_q50.jpg",
    "https://www.pikpng.com/pngl/b/209-2097143_beoplay-h9i-limestone-clipart.png",
    "https://www.pikpng.com/pngl/b/209-2097143_beoplay-h9i-limestone-clipart.png",
    "https://i.ya-webdesign.com/images/headphone-transparent-white-9.png",
  ];
}


